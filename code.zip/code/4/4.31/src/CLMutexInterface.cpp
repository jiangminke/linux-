#include "CLMutexInterface.h"

CLMutexInterface::CLMutexInterface()
{
}

CLMutexInterface::~CLMutexInterface()
{
}

