#include "CLExecutiveInitialFinishedNotifier.h"

CLExecutiveInitialFinishedNotifier::CLExecutiveInitialFinishedNotifier()
{
}

CLExecutiveInitialFinishedNotifier::~CLExecutiveInitialFinishedNotifier()
{
}

